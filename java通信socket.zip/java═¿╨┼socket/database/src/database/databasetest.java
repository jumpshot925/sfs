package database;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map; 
public class databasetest {	
	final static String URL = "jdbc:sqlserver://localhost:1433;databaseName=user";	
	final static String SQLSERVERDRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";	
	final static String USERNAME = "sa";	
	final static String PASSWORD = "likanglin88"; 	
	//��ȡ���ݿ������
	public Map<String,String> getusers() throws ClassNotFoundException, SQLException{
		Map<String,String> yourMap = new HashMap<String,String>();
		Class.forName(SQLSERVERDRIVER);		
		Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);		
		Statement stmt=conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		ResultSet rsst = stmt.executeQuery("select * from dbo.users");  //select����*��ʾ�����ֶΣ�Ҳ����ָ��������ֶ�
		while(rsst.next()) 
		{
		String  key= rsst.getString(1);
		String value = rsst.getString(2);
        yourMap.put(key, value);
		}
		rsst.close();
		stmt.close();	
		conn.close();
		return yourMap;
		
	}
	
//	public static void main(String[] args) throws Exception {		
//		databasetest a=new databasetest();
//		Map<String,String> yourMap = new HashMap<String,String>();
//		yourMap=a.getusers();
//		Iterator<String> it = yourMap.keySet().iterator();  //map.keySet()�õ�����set���ϣ�����ʹ�õ���������
//		while(it.hasNext()){
//			String key = it.next();
//			System.out.println("keyֵ��"+key+" valueֵ��"+yourMap.get(key));
//		}
//
//		
//	} 

}
