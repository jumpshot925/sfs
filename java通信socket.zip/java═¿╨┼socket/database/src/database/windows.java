package database;

import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JOptionPane;

public class windows {
	windows(){
		Frame f=new Frame("soceket�����¼����");
		int r = 249;
		int g = 205;
		int b = 173;
		Color bgColor = new Color(r, g, b);
		// ���ñ�����ɫ
		f.setBackground(bgColor);
		f.setBounds(400,200,500,500);
		f.setLayout(new FlowLayout());
		f.setResizable(false);
		Font f1 = new Font("Helvetica",Font.PLAIN,18);
		Font f2 = new Font("Helvetica",Font.PLAIN,28);
		Label temp=new Label("                                                                                                                 ");
		Label temp2=new Label("                                                                                                                 ");
		Label title=new Label("            socket����ϵͳ��¼            ");
		title.setFont(f2);
		temp.setFont(f1);
		temp2.setFont(f1);
		Label a=new Label("account:");
		a.setFont(f1);
		TextField account = new TextField(30);
		account.setFont(f1);
		Label p=new Label("password:");
		p.setFont(f1);
		TextField password = new TextField(30);
		password.setFont(f1);
		Button login = new Button("login");

		login.setFont(f1);

		f.add(title);
		f.add(a);
		f.add(account);
		f.add(temp);
		f.add(p);
		f.add(password);
		f.add(temp2);
		f.add(login);

		f.addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
		        System.exit(0);
		    }
		});
		login.addActionListener(new ActionListener() {

		    @Override
		    public void actionPerformed(ActionEvent e) {
		    	databasetest con=new databasetest();
		    	String acc=account.getText();
		    	String pass=password.getText();
		    	Map<String,String> yourMap = new HashMap<String,String>();
				try {
					yourMap=con.getusers();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Iterator<String> it = yourMap.keySet().iterator();  //map.keySet()�õ�����set���ϣ�����ʹ�õ���������
				while(it.hasNext()){
					String key = it.next();
					System.out.println("keyֵ"+key+"valueֵ"+yourMap.get(key));
					if(key.trim().equals(acc)&&yourMap.get(key).trim().equals(pass)) {
		    			JOptionPane.showMessageDialog(null, "successful", "��ӭ"+key+"���������ң�", JOptionPane.PLAIN_MESSAGE);
		    			f.setVisible(false);
		    			windows2 win=new windows2();
		    			break;
		    		}
		    		JOptionPane.showMessageDialog(null, "����������ʧ��!ʧ��ԭ���ǣ�[�û�������ȷ��������󣬷����������] ", "��WRONG!��", JOptionPane.ERROR_MESSAGE);
				}

		    }
		});
		f.setVisible(true);
			}
			public static void main(String[] args) {
				windows windows1=new windows();
			}
			static public class windows2{
				Client_1 aaa=null;
				windows2(){
				
					 try {
						aaa = new Client_1();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					Frame a=new Frame("socket");
					int r = 252;
					int g = 157;
					int b = 154;
					Color bgColor = new Color(r, g, b);
					// ���ñ�����ɫ
					a.setBackground(bgColor);
					a.setBounds(400,200,700,400);
					a.setResizable(false);
					a.addWindowListener(new WindowAdapter() {
					    public void windowClosing(WindowEvent e) {
					        System.exit(0);
					    }
					});
					a.setLayout(new FlowLayout());
					Font f = new Font("Helvetica",Font.PLAIN,18);
					TextArea area=new TextArea();
					TextField edit = new TextField(30);
					area.setFont(f);
					area.setEditable(false);
					Button send=new Button("����");  
					send.addActionListener(new ActionListener() {
					    @Override
					    public void actionPerformed(ActionEvent e) {
					    String s=edit.getText();
					   
					    edit.setText("");
					    area.append("��:"+s+"\r\n");
					    if(s.equals("bye")) {
					    	area.append("�������\r\n");
					    	return;
					    }
					    try {
					    	if(s.length()>=4) {
					    	if(s.substring(0,4).equals("send")) {
					    		area.append("���ڴ����ļ���"+s.substring(s.indexOf(" "))+"\r\n");
					    		area.append("�ļ��������");
								  aaa.sendFile(s.substring(s.indexOf(" ")));
								  return;
					    	}
					    	}
							String ans=aaa.sendmessage(s);
							//System.out.println("aaa:"+ans);
							area.append("��������"+ans+"\r\n");
							
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					    }
					});
				    Font f3 = new Font("Helvetica",Font.PLAIN,28);
					send.setFont(f3);	
					edit.setFont(f3);
					a.add(area);
					a.add(edit);
					a.add(send);									
					a.setVisible(true);
					
				}
			
			}
}
