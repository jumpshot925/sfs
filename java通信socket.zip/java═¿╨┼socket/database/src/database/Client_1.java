package database;
import java.net.*;
import java.io.*;
import java.io.IOException;
import java.util.Scanner;

public class Client_1 {
	Socket socket;
	private FileInputStream fis; 
    private DataOutputStream dos;
	Client_1() throws UnknownHostException, IOException{
		socket = new Socket("localhost", 4440);
	}
	  public  String sendmessage(String str) throws IOException {
	    InputStreamReader isr;
	    BufferedReader br;
	    OutputStreamWriter osw;
	    BufferedWriter bw;
	   
	        osw = new OutputStreamWriter(socket.getOutputStream());
	        bw = new BufferedWriter(osw);
	        System.out.print("�ظ�:");
	        //str = in.nextLine();
	        bw.write(str + "\n");
	        bw.flush();
	        isr = new InputStreamReader(socket.getInputStream());
	      br = new BufferedReader(isr);
	      //String temp=socket.getInetAddress() + ":" + br.readLine();
	      String temp=br.readLine();
	      String result=temp.substring(temp.indexOf(":\""), temp.indexOf("}"));
	        System.out.println(result);
	        return result;
	     // }
	   
	  }
	  public void sendFile(String path) throws Exception {
	        try {
	            File file = new File(path);
	            if(file.exists()) {
	                fis = new FileInputStream(file);
	                dos = new DataOutputStream(socket.getOutputStream());
	 
	                // �ļ����ͳ���
	                dos.writeUTF(file.getName());
	                dos.flush();
	                dos.writeLong(file.length());
	                dos.flush();
	 
	                // ��ʼ�����ļ�
	                System.out.println("======== ��ʼ�����ļ� ========");
	                byte[] bytes = new byte[1024];
	                int length = 0;
	                long progress = 0;
	                while((length = fis.read(bytes, 0, bytes.length)) != -1) {
	                    dos.write(bytes, 0, length);
	                    dos.flush();
	                    progress += length;
	                    System.out.print("| " + (100*progress/file.length()) + "% |");
	                }
	                System.out.println();
	                System.out.println("======== �ļ�����ɹ� ========");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            if(fis != null)
	                fis.close();
	            if(dos != null)
	                dos.close();
	            socket.close();
	        }
	    }

}
